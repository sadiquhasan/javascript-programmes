// squaroot of the number

const num= prompt("enter the number");
const res = Math.sqrt(num);
console.log(res);