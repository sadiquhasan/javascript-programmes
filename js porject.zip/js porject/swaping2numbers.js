// swapping of two numbers

let a = prompt("enter first number");
let b = prompt("enter the 2nd number");
var temp;
temp=a;
a=b;
b=temp;
console.log(a);
console.log(b);