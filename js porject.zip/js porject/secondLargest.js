// find the second largest one
let a=["T","Y","F","O","N"];
a.sort();
console.log(a[a.length-2]);