var x = [5,8,9,6,8,8,5]
var sum = 0

for(var i=0; i<x.length; i++){
    sum += x[i];
}

document.write(sum);