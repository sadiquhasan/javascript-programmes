//Check Even odd Number
var x = 50;

if(x%2 == 0){
    document.write("Even Number");
}else{
    document.write("Odd Number");
}