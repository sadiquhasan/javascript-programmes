// multiplication table
const number= parseInt(prompt("enter the integer"))
for( let i=1;i<=10;i++){
    const k= i*number;
    console.log(number+" * "+i+" = "+k)
}