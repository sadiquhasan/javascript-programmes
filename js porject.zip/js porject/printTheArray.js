var x = [8,9,6,5,8,6,9];

for(let i=1; i<x.length; i++){
    console.log(x[i]+" ");
}