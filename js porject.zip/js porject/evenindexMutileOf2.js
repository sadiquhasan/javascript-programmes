// multiply by 2 for even numbers

let x=[1,2,3,4,5];
for( var i=0; i<x.length; i++){
    if( x[i]/2 == 0){
         x[i]*=2;
    }
}
document.write(x);
