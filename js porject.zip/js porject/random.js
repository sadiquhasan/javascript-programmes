// code to get a random number
 var b = Math.random() ;
 console.log(b);