// filter  length greater than 5
var x=["abc","abcdef","xyzab","23456"];
var y=x.filter(e=>e.length>=5);
console.log(y);