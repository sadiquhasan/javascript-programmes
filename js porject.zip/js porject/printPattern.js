for(var x=1; x<=5; x++){
    for(var y=1; y<=5; y++){
        document.write("*");
    }
}