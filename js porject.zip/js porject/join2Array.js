var x = [1,2,3,5,6];
var y = [4,5,6,7,8];
var z = new Array();

for(var i=0; i<x.length; i++){
   z.push(x[i]);
}

for(var i=0; i<y.length; i++){
   y.push(y[i]);
}
