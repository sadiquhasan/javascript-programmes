

// reverse string  without using the reverse()


let s="javascript";
let rever_s=""
for( var i=s.length-1; i>=0; i--){
    rever_s += s[i] ;
}
console.log(rever_s);