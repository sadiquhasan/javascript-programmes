// largest of the three numbes;

const a=parseFloat(prompt("enter the first number"));
const b=parseFloat(prompt("enter the first number"));
const c=parseFloat(prompt("enter the first number"));

const d=Math.max(a,b,c);
console.log(d);